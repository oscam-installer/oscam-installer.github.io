# -*- coding: utf-8 -*-
PV = "1.14"
PN = "MultiBoot Selector"
PD = "Select the slot to boot from"
