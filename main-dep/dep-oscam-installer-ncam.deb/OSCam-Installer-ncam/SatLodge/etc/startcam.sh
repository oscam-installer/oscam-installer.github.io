#!/bin/sh
/usr/camscript/ncam_bin.sh cam_up &