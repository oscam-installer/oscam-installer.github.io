#!/bin/sh
/usr/camscript/oscam_emu_roland.sh cam_up &