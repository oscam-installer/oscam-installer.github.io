#!/bin/sh
/usr/camscript/oscam_bin.sh cam_up &