#!/bin/sh
CAMNAME=OScam-Installer
BINNAME=oscam_bin_neon


remove_tmp ()
{
 [ -e /tmp/ecm.info ] && rm -rf /tmp/ecm.info
 [ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
 }

case "$1" in
	start)
	remove_tmp
		systemctl stop dccamd
	sleep 2	
		systemctl disable dccamd
	sleep 2
		systemctl start $BINNAME
	sleep 2
		systemctl enable $BINNAME
	sleep 2
	;;
	stop)
		remove_tmp
		systemctl stop $BINNAME
	sleep 2
		systemctl disable $BINNAME
	sleep 2
	;;
	restart|reload)
	$0 stop
	sleep 3
	$0 start
     ;;
	*)
		$0 stop
		exit 1
	;;
esac
exit 0