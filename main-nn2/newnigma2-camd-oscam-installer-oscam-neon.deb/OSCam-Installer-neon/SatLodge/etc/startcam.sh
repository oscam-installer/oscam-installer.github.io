#!/bin/sh
/usr/camscript/oscam_bin_neon.sh cam_up &