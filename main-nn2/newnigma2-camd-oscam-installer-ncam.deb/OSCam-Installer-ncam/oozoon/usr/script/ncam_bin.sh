#!/bin/sh

OSD="ncam_bin"
PID=$(pidof $OSD)
Action=$1

cam_clean() {
    rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/ncam* /tmp/.ncam
}
cam_handle() {
    if test -z "${PID}"; then
        cam_up
    else
        cam_down
    fi
}
cam_down() {
    killall -9 ${OSD}
    sleep 2
    cam_clean
}
cam_up() {
    cam_clean
    /usr/bin/camd/${OSD} -c /etc/tuxbox/config/ncam &
}
if test "$Action" = "cam_startup"; then
    if test -z "${PID}"; then
        cam_down
        cam_up
    else
        echo "${OSD} already running, exiting..."
    fi
elif test "$Action" = "cam_res"; then
    cam_down
    cam_up
elif test "$Action" = "cam_down"; then
    cam_down
elif test "$Action" = "cam_up"; then
    cam_up
else
    cam_handle
fi
exit 0
