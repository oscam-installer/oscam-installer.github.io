#!/bin/sh
/usr/camscript/oscam_bin_emu.sh cam_up &