#!/bin/sh
/usr/camscript/oscam_bin_neon_emu.sh cam_up &