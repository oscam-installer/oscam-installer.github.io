#!/bin/sh
/usr/camscript/oscam_roland.sh cam_up &