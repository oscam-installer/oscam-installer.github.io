# WireGuard install
import os


def startInstall():
    # do update feed
    error = []

    os.system("apt-get update")

    check = os.popen("opkg list-installed | grep libmnl0")
    check = check.read()
    if "libmnl0" not in check:
        install = os.popen("apt-get -y -f install libmnl0")
        install = install.read()
        if "Setting up" in install:
            print("WireGuard: installed libmnl0")
        else:
            print("WireGuard: install libmnl0 error")
            error.append("install libmnl0 error")
    else:
        print("WireGuard: libmnl0 OK")

    check = os.popen("opkg list-installed | grep init-ifupdown")
    check = check.read()
    if "init-ifupdown" not in check:
        install = os.popen("apt-get -y -f install init-ifupdown")
        install = install.read()
        if "Setting up" in install:
            print("WireGuard: installed init-ifupdown")
        else:
            install = os.popen("dpkg -i /tmp/WireGuard_ONE/init-ifupdown/init-ifupdown*.deb && apt-get -f install")
            install = install.read()
            if "Setting up" in install:
                print("WireGuard: installed init-ifupdown")
            else:
                print("WireGuard: install init-ifupdown error")
                error.append("install init-ifupdown error")
    else:
        print("WireGuard: init-ifupdown OK")

    check = os.popen("opkg list-installed | grep iproute2")
    check = check.read()
    if "iproute2" not in check:
        install = os.popen("apt-get -y -f install iproute2")
        install = install.read()
        if "Setting up" in install:
            print("WireGuard: installed iproute2")
        else:
            print("WireGuard: install iproute2 error")
            error.append("install iproute2 error")
    else:
        print("WireGuard: iproute2 OK")

    check = os.popen("opkg list-installed | grep kernel-module-xt-addrtype")
    check = check.read()
    if "kernel-module-xt-addrtype" not in check:
        install = os.popen("apt-get -y -f install kernel-module-xt-addrtype")
        install = install.read()
        if "Setting up" in install:
            print("WireGuard: installed kernel-module-xt-addrtype")
        else:
            print("WireGuard: install kernel-module-xt-addrtype error")
            error.append("install kernel-module-xt-addrtype error")
    else:
        print("WireGuard: kernel-module-xt-addrtype OK")

    for paket in os.listdir("/tmp/WireGuard_ONE/iptables"):
        paket_file = "/tmp/WireGuard_ONE/iptables/" + paket
        paket_name = paket.split("_")[0]
        if os.path.isfile(paket_file):
            install = os.popen("dpkg -i --force-depends %s" % paket_file)
            install = install.read()
            if "Setting up" in install:
                print("WireGuard: %s" % paket_name)
            else:
                print("WireGuard: install %s error" % paket_name)
                error.append("install %s error" % paket_name )

    # install iptables paket's
    for paket in os.listdir("/tmp/WireGuard_ONE/iptables/module"):
        paket_file = "/tmp/WireGuard_ONE/iptables/module/" + paket
        paket_name = paket.split("_")[0]
        if os.path.isfile(paket_file):
            install = os.popen("dpkg -i %s" % paket_file)
            install = install.read()
            if "Setting up" in install:
                print("WireGuard: %s" % paket_name)
            else:
                print("WireGuard: install %s error" % paket_name)
                error.append("install %s error" % paket_name)
    # install WireGuard Tool
    for paket in os.listdir("/tmp/WireGuard_ONE/WireGuardModule"):
        paket_file = "/tmp/WireGuard_ONE/WireGuardModule/" + paket
        paket_name = paket.split("_")[0]
        if os.path.isfile(paket_file):
            install = os.popen("dpkg -i %s" % paket_file)
            install = install.read()
            if "Setting up" in install:
                print("WireGuard: %s" % paket_name)
            else:
                print("WireGuard: install %s error" % paket_name)
                error.append("install %s error" % paket_name)

    # install openresolv
    for paket in os.listdir("/tmp/WireGuard_ONE/openresolv"):
        paket_file = "/tmp/WireGuard_ONE/openresolv/" + paket
        paket_name = paket.split("_")[0]
        if os.path.isfile(paket_file):
            install = os.popen("dpkg -i %s" % paket_file)
            install = install.read()
            if "Setting up" in install:
                print("WireGuard: %s" % paket_name)
            else:
                print("WireGuard: install %s error" % paket_name)
                error.append("install %s error" % paket_name)

    # install libnfnetlink
    for paket in os.listdir("/tmp/WireGuard_ONE/libnfnetlink"):
        paket_file = "/tmp/WireGuard_ONE/libnfnetlink/" + paket
        paket_name = paket.split("_")[0]
        if os.path.isfile(paket_file):
            install = os.popen("dpkg -i %s" % paket_file)
            install = install.read()
            if "Setting up" in install:
                print("WireGuard: %s" % paket_name)
            else:
                print("WireGuard: install %s error" % paket_name)
                error.append("install %s error" % paket_name)

    if error:
        print("WireGuard has the following installation errors!")
        for e in error:
            print(e)
    else:
        print("WireGuard has been successfully installed!")


def main():
    startInstall()


if __name__ == '__main__':
    main()
