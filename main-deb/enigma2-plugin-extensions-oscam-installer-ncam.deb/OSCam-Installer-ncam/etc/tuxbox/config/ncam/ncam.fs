# This file work as like CCcam.cfg (For free sever and keep CCCam.cfg for buy C: line)
